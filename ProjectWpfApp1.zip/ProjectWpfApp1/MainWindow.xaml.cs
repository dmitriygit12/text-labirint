﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static ProjectWpfApp1.MainWindow;
using static System.Net.Mime.MediaTypeNames;

namespace ProjectWpfApp1
{
    public partial class MainWindow : Window
    {
        public class Item
        {
            public string Title { get; set; }
            public int price { get; set; }
        }

        public ObservableCollection<Item> Tasks { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // Заполняем список данными
            Tasks = new ObservableCollection<Item>
            {
                new Item { Title = "Зелье здоровья", price = 120 },
                new Item { Title = "Меч", price = 110 },
                new Item { Title = "Щит", price = 100 }
            };

            // Указываем контекст данных для привязки в XAML
            DataContext = this;
        }

        private void InputTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                string enteredText = InputTextBox.Text;
                if(InputTextBox.Text == "Пойти вверх")
                {
                    pathCheck(InputTextBox.Text);
                }
                else if (InputTextBox.Text == "Пойти вниз")
                {
                    pathCheck(InputTextBox.Text);
                }
                else if (InputTextBox.Text == "Пойти вправо")
                {
                    pathCheck(InputTextBox.Text);
                }
                else if (InputTextBox.Text == "Пойти влево")
                {
                    pathCheck(InputTextBox.Text);
                }
                else if (InputTextBox.Text == "Просмотр инвертаря")
                {
                    ToggleView();
                }
                else if (InputTextBox.Text == "Закрыть")
                {
                    ToggleView();
                }
                else
                {
                    string s = "Неизвестная команда";
                    Print(s);

                }

                    InputTextBox.Clear();
            }
        }
        public void pathCheck(string path)
        {
            if (path == "Пойти вверх")
            {
                var uri = new Uri($"pack://application:,,,{"/Images /room_1.jpg"}", UriKind.Absolute);
                MyImage.Source = new BitmapImage(uri);
                Print("Конец");
            }
            else if (path == "Пойти вниз")
            {
                Print("Туда пройти нельзя");
            }
            else if (path == "Пойти вправо")
            {
                Print("Туда пройти нельзя");
            }
            else if (path == "Пойти влево")
            {
                Print("Туда пройти нельзя");
            }
        }
        
        
        public void Print(string text)
        {
            StatusTextBlock.Text = text;
        }

        

        private void ToggleView()
        {
            bool isListHidden = MyListBox.Visibility == Visibility.Collapsed;

            MyListBox.Visibility = isListHidden ? Visibility.Visible : Visibility.Collapsed;
            MyImage.Visibility = isListHidden ? Visibility.Collapsed : Visibility.Visible;
        }
    } 
}
